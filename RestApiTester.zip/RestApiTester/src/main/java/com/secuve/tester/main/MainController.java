package com.secuve.tester.main;

import com.secuve.tester.util.RestClient;

public class MainController implements Runnable {

	String url = "http://172.16.0.215:8080";

	private int[] temp;
	private RestClient restClient;

	public MainController() {
		
		restClient = new RestClient(url);
		
		temp = new int[5];

		for (int start = 0; start < temp.length; start++) {
			temp[start] = start;
		}
	}

	@Override
	public void run() {
		
		for (int start : temp) {
			try {
				
				//api 정의

			} catch (Exception ie) {
				ie.printStackTrace();
			}

		}
	}

	public static void main(String[] args) {

		MainController ct = new MainController();
		Thread t = new Thread(ct, "thread");

		t.start();
		
		//multi-thread
//		Thread t2 = new Thread(ct, "thread");
//		t2.start();
		
	}

}
