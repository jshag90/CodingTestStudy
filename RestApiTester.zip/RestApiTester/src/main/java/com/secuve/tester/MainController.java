package com.secuve.tester;

import java.util.ArrayList;

import org.json.simple.JSONObject;

public class MainController implements Runnable {

	String url = "https://www.secuvecert1.com:18443";

	private int[] temp;

	public MainController() {
		temp = new int[10];

		for (int start = 0; start < temp.length; start++) {
			temp[start] = start;
		}
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for (int start : temp) {
			try {
//				Thread.sleep(1000);

				RestClient restClient = new RestClient(url);
				TestController tc = new TestController();

				JSONObject sendData = new JSONObject();
				String userkey = "12345";
//				String deviceId = "12345";
//				String deviceInfo = "deviceInfo";
//				String deviceType = "ios";
//
//				tc.callRegDevice(restClient, sendData, userkey, deviceId, deviceInfo, deviceType);
				////////////////////
				String signName = "signName";
				String orientation = "1";
				String signData = "[(848,1613,0)]";
				
//				tc.callRegSign(restClient, sendData, userkey, signName, orientation, signData);
				////////////////////
				ArrayList reg_sign_ids = new ArrayList<String>();
				reg_sign_ids.add("bc1ce86812301212111212331312331182111111173323a33#41023181#11");
				reg_sign_ids.add("bc1ce86812301212111212331312331182111111173323a33#41023181#12");
				reg_sign_ids.add("bc1ce86812301212111212331312331182111111173323a33#41023181#13");
				
				String auth_sign_name = "authSignName";
				String authSignData = "[(1,2,3)]";
				String authThreshold = "90";
				String logLevel = "debug";
				tc.callAuthSign(restClient, userkey, reg_sign_ids, auth_sign_name, authSignData, authThreshold, orientation, logLevel);

			} catch (Exception ie) {
				ie.printStackTrace();
			}

//			System.out.println("스레드이름:" + Thread.currentThread().getName());
//			System.out.println("temp value :" + start);
		}
	}

	public static void main(String[] args) {

		MainController ct = new MainController();
		Thread t = new Thread(ct, "첫번째");

		t.start();
	}

}
